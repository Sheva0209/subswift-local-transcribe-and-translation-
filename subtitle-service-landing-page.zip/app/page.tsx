import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { HowItWorks } from '@/components/how-it-works'
import { Pricing } from '@/components/pricing'
import { UseCases } from '@/components/use-cases'
import { OrderForm } from '@/components/order-form'
import { Faq } from '@/components/faq'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <div className="min-h-svh bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <HowItWorks />
        <Pricing />
        <UseCases />
        <OrderForm />
        <Faq />
      </main>
      <SiteFooter />
    </div>
  )
}
