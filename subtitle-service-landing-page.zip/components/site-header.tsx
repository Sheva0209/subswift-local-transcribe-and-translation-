import Link from 'next/link'
import { Button } from '@/components/ui/button'

const links = [
  { href: '#how-it-works', label: 'How it works' },
  { href: '#pricing', label: 'Pricing' },
  { href: '#use-cases', label: 'Use cases' },
  { href: '#faq', label: 'FAQ' },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-6 px-5">
        <Link href="/" className="flex items-center gap-2.5">
          <span
            aria-hidden="true"
            className="flex h-7 items-end gap-[3px] rounded-sm"
          >
            <span className="h-3 w-[3px] rounded-full bg-primary" />
            <span className="h-6 w-[3px] rounded-full bg-primary" />
            <span className="h-4 w-[3px] rounded-full bg-primary/60" />
            <span className="h-7 w-[3px] rounded-full bg-primary" />
          </span>
          <span className="text-base font-semibold tracking-tight">
            Subline
          </span>
        </Link>

        <nav aria-label="Main" className="hidden items-center gap-7 md:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <Button
          render={<a href="#order" />}
          nativeButton={false}
          size="sm"
          className="font-medium"
        >
          Order now
        </Button>
      </div>
    </header>
  )
}
