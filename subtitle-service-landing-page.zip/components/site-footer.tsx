import Link from 'next/link'

export function SiteFooter() {
  return (
    <footer className="py-12">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 px-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-col gap-1">
          <span className="text-sm font-semibold tracking-tight">Subline</span>
          <p className="text-sm text-muted-foreground">
            Fast subtitles and translation for people on a deadline.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
          <Link
            href="#pricing"
            className="text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            Pricing
          </Link>
          <Link
            href="#faq"
            className="text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            FAQ
          </Link>
          <a
            href="mailto:hello@subline.studio"
            className="text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            hello@subline.studio
          </a>
        </div>
      </div>
    </footer>
  )
}
