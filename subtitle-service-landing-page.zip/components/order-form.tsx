'use client'

import { useState } from 'react'
import { ArrowRight, CheckCircle2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import {
  Field,
  FieldDescription,
  FieldGroup,
  FieldLabel,
  FieldTitle,
} from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'

const languages = [
  'English',
  'Indonesian',
  'Spanish',
  'Portuguese',
  'French',
  'German',
  'Japanese',
  'Korean',
  'Mandarin Chinese',
  'Arabic',
  'Hindi',
  'Vietnamese',
]

const rates: Record<string, number> = { draft: 0.6, standard: 1.4 }

export function OrderForm() {
  const [tier, setTier] = useState('draft')
  const [duration, setDuration] = useState('')
  const [sourceLanguage, setSourceLanguage] = useState('English')
  const [targetLanguage, setTargetLanguage] = useState('Indonesian')
  const [submitted, setSubmitted] = useState(false)

  const minutes = Number.parseFloat(duration)
  const estimate =
    Number.isFinite(minutes) && minutes > 0 ? minutes * rates[tier] : null

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setSubmitted(true)
    toast.success('Order request sent', {
      description: 'We reply with a confirmed quote within a few hours.',
    })
  }

  return (
    <section
      id="order"
      className="scroll-mt-16 border-b border-border py-20 md:py-24"
    >
      <div className="mx-auto grid w-full max-w-6xl gap-12 px-5 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        <div className="flex flex-col gap-4 lg:sticky lg:top-28 lg:self-start">
          <span className="font-mono text-[11px] tracking-widest text-primary uppercase">
            Order
          </span>
          <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            Tell us about the video
          </h2>
          <p className="text-base leading-relaxed text-muted-foreground">
            No payment yet. We read every request by hand, confirm the price and
            deadline, and only then start the work.
          </p>
          <dl className="mt-2 flex flex-col gap-4 border-t border-border pt-6">
            <div className="flex flex-col gap-1">
              <dt className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
                Reply time
              </dt>
              <dd className="text-sm text-foreground">
                Usually under 3 hours, 09:00&ndash;22:00 GMT+7
              </dd>
            </div>
            <div className="flex flex-col gap-1">
              <dt className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
                Prefer email?
              </dt>
              <dd className="text-sm text-foreground">hello@subline.studio</dd>
            </div>
          </dl>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 sm:p-8">
          {submitted ? (
            <div className="flex flex-col items-start gap-4 py-8">
              <CheckCircle2
                className="size-8 text-primary"
                aria-hidden="true"
                strokeWidth={1.75}
              />
              <h3 className="text-xl font-semibold tracking-tight">
                Request received
              </h3>
              <p className="max-w-md text-sm leading-relaxed text-muted-foreground">
                Thanks &mdash; we have your details. Expect a reply with the
                confirmed quote and delivery time shortly. If it&apos;s urgent,
                email hello@subline.studio and mention your name.
              </p>
              <Button
                variant="outline"
                onClick={() => setSubmitted(false)}
                className="font-medium"
              >
                Submit another video
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate={false}>
              <FieldGroup>
                <div className="grid gap-6 sm:grid-cols-2">
                  <Field>
                    <FieldLabel htmlFor="name">Name</FieldLabel>
                    <Input
                      id="name"
                      name="name"
                      autoComplete="name"
                      placeholder="Rani Pratama"
                      required
                    />
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="email">Email</FieldLabel>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      placeholder="you@channel.com"
                      required
                    />
                  </Field>
                </div>

                <div className="grid gap-6 sm:grid-cols-2">
                  <Field>
                    <FieldLabel htmlFor="duration">
                      Video duration (minutes)
                    </FieldLabel>
                    <Input
                      id="duration"
                      name="duration"
                      type="number"
                      min={1}
                      step={1}
                      inputMode="numeric"
                      placeholder="18"
                      value={duration}
                      onChange={(event) => setDuration(event.target.value)}
                      required
                    />
                    <FieldDescription>
                      Total across all videos if you&apos;re sending a batch.
                    </FieldDescription>
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="deadline">Deadline</FieldLabel>
                    <Input id="deadline" name="deadline" type="date" required />
                    <FieldDescription>
                      When you need the file in hand.
                    </FieldDescription>
                  </Field>
                </div>

                <div className="grid gap-6 sm:grid-cols-2">
                  <Field>
                    <FieldLabel htmlFor="source-language">
                      Source language
                    </FieldLabel>
                    <Select
                      value={sourceLanguage}
                      onValueChange={(value) =>
                        setSourceLanguage(value as string)
                      }
                    >
                      <SelectTrigger id="source-language" className="w-full">
                        <SelectValue placeholder="Spoken in the video" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          {languages.map((language) => (
                            <SelectItem key={language} value={language}>
                              {language}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="target-language">
                      Target language
                    </FieldLabel>
                    <Select
                      value={targetLanguage}
                      onValueChange={(value) =>
                        setTargetLanguage(value as string)
                      }
                    >
                      <SelectTrigger id="target-language" className="w-full">
                        <SelectValue placeholder="Subtitle output" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          {languages.map((language) => (
                            <SelectItem key={language} value={language}>
                              {language}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </Field>
                </div>

                <Field>
                  <FieldTitle id="tier-label">Tier</FieldTitle>
                  <ToggleGroup
                    aria-labelledby="tier-label"
                    spacing={2}
                    value={[tier]}
                    onValueChange={(value) => {
                      if (value.length > 0) setTier(value[0] as string)
                    }}
                  >
                    <ToggleGroupItem value="draft">
                      Draft &middot; $0.60/min
                    </ToggleGroupItem>
                    <ToggleGroupItem value="standard">
                      Standard &middot; $1.40/min
                    </ToggleGroupItem>
                  </ToggleGroup>
                  <FieldDescription>
                    {tier === 'draft'
                      ? 'Auto-generated, timing cleaned up, back in 6–12 hours.'
                      : 'Auto-generated plus a full human review pass, back in 24–48 hours.'}
                  </FieldDescription>
                </Field>

                <Field>
                  <FieldLabel htmlFor="notes">Link & notes</FieldLabel>
                  <Textarea
                    id="notes"
                    name="notes"
                    rows={4}
                    placeholder="Drive / Dropbox / YouTube link, plus anything we should know: names to keep, tone, on-screen text, number of videos."
                    required
                  />
                </Field>

                <div className="flex flex-col gap-4 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between">
                  <p className="font-mono text-sm text-muted-foreground">
                    {estimate
                      ? `Estimate: $${estimate.toFixed(2)}`
                      : 'Estimate appears once you add a duration'}
                  </p>
                  <Button type="submit" size="lg" className="font-medium">
                    Send order request
                    <ArrowRight data-icon="inline-end" />
                  </Button>
                </div>
              </FieldGroup>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}
