import { Check, Minus } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'

const tiers = [
  {
    name: 'Draft',
    price: '$0.60',
    unit: '/ min of video',
    tag: 'Fast & cheap',
    highlight: false,
    description:
      'Auto transcription and translation with timing cleanup. Reads well, may keep an odd phrasing here and there.',
    turnaround: '6–12 hours',
    bestFor: 'Bulk YouTube uploads, backlogs, draft cuts, internal review',
    includes: [
      'Auto transcribe + translate',
      'Timing and line-break cleanup',
      'SRT or VTT delivery',
      'Bulk discount from 5 videos',
    ],
    excludes: ['Human review pass', 'Terminology / name sheet'],
  },
  {
    name: 'Standard',
    price: '$1.40',
    unit: '/ min of video',
    tag: 'Reviewed',
    highlight: true,
    description:
      'Everything in Draft, plus a human pass over the whole file for meaning, names, and readability.',
    turnaround: '24–48 hours',
    bestFor: 'Feature films, documentaries, client work, anything published',
    includes: [
      'Auto transcribe + translate',
      'Timing and line-break cleanup',
      'Light human review, full file',
      'Names & terminology kept consistent',
      'One round of revisions',
    ],
    excludes: [],
  },
]

export function Pricing() {
  return (
    <section
      id="pricing"
      className="scroll-mt-16 border-b border-border py-20 md:py-24"
    >
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-12 px-5">
        <div className="flex max-w-2xl flex-col gap-4">
          <span className="font-mono text-[11px] tracking-widest text-primary uppercase">
            Pricing
          </span>
          <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            Two tiers. Pick how much polish you actually need.
          </h2>
          <p className="text-base leading-relaxed text-muted-foreground">
            Priced per minute of video, not per word. Same pipeline underneath
            &mdash; the difference is whether a human reads it before you do.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {tiers.map((tier) => (
            <Card
              key={tier.name}
              className={
                tier.highlight
                  ? 'border-primary/50 bg-card ring-1 ring-primary/20'
                  : 'bg-card'
              }
            >
              <CardHeader>
                <div className="flex items-center gap-3">
                  <CardTitle className="text-xl tracking-tight">
                    {tier.name}
                  </CardTitle>
                  <Badge variant={tier.highlight ? 'default' : 'secondary'}>
                    {tier.tag}
                  </Badge>
                </div>
                <CardDescription className="leading-relaxed">
                  {tier.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="flex flex-col gap-6">
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-4xl tracking-tight text-foreground">
                    {tier.price}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {tier.unit}
                  </span>
                </div>

                <dl className="grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2">
                  <div className="flex flex-col gap-1 bg-background p-4">
                    <dt className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
                      Turnaround
                    </dt>
                    <dd className="text-sm text-foreground">
                      {tier.turnaround}
                    </dd>
                  </div>
                  <div className="flex flex-col gap-1 bg-background p-4">
                    <dt className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
                      Best for
                    </dt>
                    <dd className="text-sm leading-relaxed text-foreground">
                      {tier.bestFor}
                    </dd>
                  </div>
                </dl>

                <ul className="flex flex-col gap-2.5">
                  {tier.includes.map((item) => (
                    <li key={item} className="flex items-start gap-2.5">
                      <Check
                        className="mt-0.5 size-4 shrink-0 text-primary"
                        aria-hidden="true"
                        strokeWidth={2}
                      />
                      <span className="text-sm leading-relaxed text-foreground">
                        {item}
                      </span>
                    </li>
                  ))}
                  {tier.excludes.map((item) => (
                    <li key={item} className="flex items-start gap-2.5">
                      <Minus
                        className="mt-0.5 size-4 shrink-0 text-muted-foreground"
                        aria-hidden="true"
                        strokeWidth={2}
                      />
                      <span className="text-sm leading-relaxed text-muted-foreground">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Button
                  render={<a href="#order" />}
                  nativeButton={false}
                  variant={tier.highlight ? 'default' : 'outline'}
                  className="w-full font-medium"
                >
                  Order {tier.name}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">
          Ordering 5+ videos at once, or a series? Mention it in the notes field
          and we&apos;ll quote a flat bulk rate instead.
        </p>
      </div>
    </section>
  )
}
