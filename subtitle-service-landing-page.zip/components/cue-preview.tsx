'use client'

import { useEffect, useState } from 'react'

const cues = [
  {
    time: '00:00:04,120',
    source: 'So the trick is to shoot it all in one take.',
    target: 'Jadi triknya adalah merekam semuanya dalam satu take.',
  },
  {
    time: '00:00:07,480',
    source: 'No cuts, no second chances.',
    target: 'Tanpa potongan, tanpa kesempatan kedua.',
  },
  {
    time: '00:00:10,000',
    source: 'And that is where most people give up.',
    target: 'Dan di situlah sebagian besar orang menyerah.',
  },
  {
    time: '00:00:13,640',
    source: 'But we are not most people, are we?',
    target: 'Tapi kita bukan sebagian besar orang, kan?',
  },
]

export function CuePreview() {
  const [active, setActive] = useState(0)

  useEffect(() => {
    const id = window.setInterval(() => {
      setActive((prev) => (prev + 1) % cues.length)
    }, 2600)
    return () => window.clearInterval(id)
  }, [])

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="flex items-center justify-between gap-4 border-b border-border px-4 py-3">
        <span className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
          episode-047.srt
        </span>
        <span className="font-mono text-[11px] text-muted-foreground">
          EN &rarr; ID
        </span>
      </div>

      <ul className="flex flex-col divide-y divide-border">
        {cues.map((cue, index) => {
          const isActive = index === active
          return (
            <li
              key={cue.time}
              className="flex gap-3 px-4 py-4 transition-colors duration-500 sm:gap-4"
              data-active={isActive || undefined}
            >
              <span
                aria-hidden="true"
                className={
                  isActive
                    ? 'mt-1 h-8 w-[3px] shrink-0 rounded-full bg-primary transition-colors duration-500'
                    : 'mt-1 h-8 w-[3px] shrink-0 rounded-full bg-border transition-colors duration-500'
                }
              />
              <div className="flex min-w-0 flex-col gap-1">
                <span className="font-mono text-[11px] text-muted-foreground">
                  {cue.time}
                </span>
                <span
                  className={
                    isActive
                      ? 'text-sm text-foreground transition-colors duration-500'
                      : 'text-sm text-muted-foreground transition-colors duration-500'
                  }
                >
                  {cue.source}
                </span>
                <span
                  className={
                    isActive
                      ? 'text-sm font-medium text-primary transition-colors duration-500'
                      : 'text-sm text-muted-foreground/60 transition-colors duration-500'
                  }
                >
                  {cue.target}
                </span>
              </div>
            </li>
          )
        })}
      </ul>

      <div className="flex items-center justify-between gap-4 border-t border-border bg-secondary/40 px-4 py-3">
        <span className="font-mono text-[11px] text-muted-foreground">
          {cues.length} of 312 cues
        </span>
        <span className="font-mono text-[11px] text-primary">
          delivered in 6h 12m
        </span>
      </div>
    </div>
  )
}
