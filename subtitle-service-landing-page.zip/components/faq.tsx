import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'

const faqs = [
  {
    value: 'accuracy',
    question: 'How accurate is it, honestly?',
    answer:
      'Draft lands around 90–95% on clear audio: correct meaning, natural enough phrasing, occasionally a stiff line or a misheard name. Standard adds a human pass over the whole file, which fixes names, jargon and awkward sentences. Neither is a certified or literary translation, and we will tell you if your audio is too rough for a good result.',
  },
  {
    value: 'turnaround',
    question: 'How fast is turnaround, really?',
    answer:
      'Draft is typically 6–12 hours and often same-day for short videos. Standard is 24–48 hours depending on length. Long films and large batches get a specific date when we confirm your quote — we would rather quote honestly than miss a deadline.',
  },
  {
    value: 'languages',
    question: 'Which languages do you support?',
    answer:
      'Over 40 language pairs, with the strongest results across English, Indonesian, Spanish, Portuguese, French, German, Japanese, Korean, Mandarin, Arabic, Hindi and Vietnamese. Ask about anything not on the list — if quality would be poor, we say so instead of taking the order.',
  },
  {
    value: 'formats',
    question: 'What files do I get, and what can you accept?',
    answer:
      'You get SRT by default, or VTT, ASS and plain text on request, plus a bilingual version if you need both languages. Send us MP4, MOV, MKV, WAV or MP3 — a Drive, Dropbox or YouTube link is easiest. Burned-in subtitles are available on request for an extra fee.',
  },
  {
    value: 'revisions',
    question: 'What if something comes back wrong?',
    answer:
      'Standard includes one revision round; tell us the timecodes and what to change. On Draft we fix genuine errors like missing lines or badly broken timing for free, but rewriting phrasing across a whole file is really a Standard job.',
  },
  {
    value: 'bulk',
    question: 'Do you do bulk or ongoing work?',
    answer:
      'Yes, that is most of what we do. Five or more videos at once gets a flat bulk rate, and creators on a weekly schedule can reserve a recurring slot so their upload never waits on captions.',
  },
]

export function Faq() {
  return (
    <section
      id="faq"
      className="scroll-mt-16 border-b border-border py-20 md:py-24"
    >
      <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        <div className="flex flex-col gap-4">
          <span className="font-mono text-[11px] tracking-widest text-primary uppercase">
            FAQ
          </span>
          <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            The questions we get before every first order
          </h2>
        </div>

        <Accordion className="w-full">
          {faqs.map((faq) => (
            <AccordionItem key={faq.value} value={faq.value}>
              <AccordionTrigger className="text-left text-base">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  )
}
