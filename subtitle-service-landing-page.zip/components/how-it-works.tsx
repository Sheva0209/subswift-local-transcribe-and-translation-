import { FileUp, Languages, Timer, Download } from 'lucide-react'

const steps = [
  {
    icon: FileUp,
    title: 'Send the video',
    body: 'A Drive or Dropbox link is fine, a YouTube link is fine too. No uploads to babysit.',
  },
  {
    icon: Languages,
    title: 'Pick languages & tier',
    body: 'Choose source and target language, then Draft for speed or Standard for a reviewed pass.',
  },
  {
    icon: Timer,
    title: 'We run it',
    body: 'Transcribe, translate, then fix the timing so lines land where the words actually land.',
  },
  {
    icon: Download,
    title: 'Get your file back',
    body: 'SRT or VTT in your inbox, ready to drop straight into YouTube or your NLE.',
  },
]

export function HowItWorks() {
  return (
    <section
      id="how-it-works"
      className="scroll-mt-16 border-b border-border py-20 md:py-24"
    >
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-12 px-5">
        <div className="flex max-w-2xl flex-col gap-4">
          <span className="font-mono text-[11px] tracking-widest text-primary uppercase">
            How it works
          </span>
          <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            Four steps, no account, no dashboard to learn
          </h2>
          <p className="text-base leading-relaxed text-muted-foreground">
            You send a link, we send a file. Everything in between is our
            problem.
          </p>
        </div>

        <ol className="grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <li
              key={step.title}
              className="flex flex-col gap-4 bg-card p-6 lg:p-7"
            >
              <div className="flex items-center justify-between gap-3">
                <step.icon
                  className="size-5 text-primary"
                  aria-hidden="true"
                  strokeWidth={1.75}
                />
                <span className="font-mono text-[11px] text-muted-foreground">
                  Step {index + 1}
                </span>
              </div>
              <h3 className="text-base font-medium tracking-tight">
                {step.title}
              </h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {step.body}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
