import { Button } from '@/components/ui/button'
import { CuePreview } from '@/components/cue-preview'

const proof = [
  { value: '6–24h', label: 'typical turnaround' },
  { value: '40+', label: 'language pairs' },
  { value: 'SRT / VTT', label: 'files you can drop in' },
]

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border">
      <div
        aria-hidden="true"
        className="grid-backdrop pointer-events-none absolute inset-0 opacity-60 [mask-image:radial-gradient(70%_60%_at_50%_0%,black,transparent)]"
      />
      <div className="relative mx-auto grid w-full max-w-6xl gap-14 px-5 py-20 md:py-28 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:gap-16">
        <div className="flex flex-col items-start gap-7">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
            <span className="size-1.5 rounded-full bg-primary" />
            Now taking bulk orders
          </span>

          <h1 className="text-4xl leading-[1.05] font-semibold tracking-tight text-balance sm:text-5xl lg:text-6xl">
            Subtitles and translation,
            <span className="text-primary"> back before your edit is.</span>
          </h1>

          <p className="max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            We transcribe and translate your video into clean, correctly timed
            subtitle files &mdash; fast and cheap. Not flawless literary
            translation. Good, readable, and on your timeline.
          </p>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Button
              render={<a href="#order" />}
              nativeButton={false}
              size="lg"
              className="font-medium"
            >
              Order now
            </Button>
            <Button
              render={<a href="#pricing" />}
              nativeButton={false}
              size="lg"
              variant="ghost"
              className="font-medium"
            >
              See pricing
            </Button>
          </div>

          <dl className="mt-2 grid w-full max-w-lg grid-cols-3 gap-4 border-t border-border pt-6">
            {proof.map((item) => (
              <div key={item.label} className="flex flex-col gap-1">
                <dt className="font-mono text-sm text-foreground">
                  {item.value}
                </dt>
                <dd className="text-xs leading-relaxed text-muted-foreground">
                  {item.label}
                </dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="lg:pl-4">
          <CuePreview />
        </div>
      </div>
    </section>
  )
}
