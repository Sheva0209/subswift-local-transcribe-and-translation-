import { MonitorPlay, Film } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'

const cases = [
  {
    icon: MonitorPlay,
    title: 'YouTube creators',
    tier: 'Draft tier',
    description:
      'You upload weekly and you have a backlog of videos with no captions in any language.',
    points: [
      'Send five or ten videos in one order',
      'Files come back same-day, ready to upload',
      'Cheap enough to caption every video, not just the big ones',
    ],
  },
  {
    icon: Film,
    title: 'Long-form film & content',
    tier: 'Standard tier',
    description:
      'A 90-minute documentary, a lecture series, or client work where wording actually matters.',
    points: [
      'Human pass over the full file before delivery',
      'Names, places and jargon kept consistent throughout',
      'One revision round if you want phrasing changed',
    ],
  },
]

export function UseCases() {
  return (
    <section
      id="use-cases"
      className="scroll-mt-16 border-b border-border py-20 md:py-24"
    >
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-12 px-5">
        <div className="flex max-w-2xl flex-col gap-4">
          <span className="font-mono text-[11px] tracking-widest text-primary uppercase">
            Use cases
          </span>
          <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            Built for two very different deadlines
          </h2>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {cases.map((item) => (
            <Card key={item.title} className="bg-card">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <span className="flex size-9 items-center justify-center rounded-lg bg-secondary">
                    <item.icon
                      className="size-4.5 text-primary"
                      aria-hidden="true"
                      strokeWidth={1.75}
                    />
                  </span>
                  <CardTitle className="text-lg tracking-tight">
                    {item.title}
                  </CardTitle>
                  <Badge variant="outline" className="ml-auto font-mono">
                    {item.tier}
                  </Badge>
                </div>
                <CardDescription className="leading-relaxed">
                  {item.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="flex flex-col gap-3 border-t border-border pt-5">
                  {item.points.map((point) => (
                    <li
                      key={point}
                      className="flex items-start gap-3 text-sm leading-relaxed text-muted-foreground"
                    >
                      <span
                        aria-hidden="true"
                        className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary"
                      />
                      {point}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
